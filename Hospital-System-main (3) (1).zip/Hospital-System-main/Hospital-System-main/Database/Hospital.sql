-- Create the hospital database
CREATE DATABASE IF NOT EXISTS hospital;

-- Use the hospital database
USE hospital;

-- Create patients table
CREATE TABLE patients (
    ssn INT PRIMARY KEY,
    name NVARCHAR(100),
    medical_insurance NVARCHAR(50),
    date_admitted DATE,
    date_of_checked_out DATE
);

-- Insert data into patients table
INSERT INTO patients VALUES (1, 'ahmed', 'free medicine', '2024-03-23', '2024-04-01');
INSERT INTO patients VALUES (2, 'mohamed', 'free medicine', '2024-02-13', '2024-02-15');
INSERT INTO patients VALUES (3, 'seif', 'free detection', '2024-01-01', '2024-03-25');
INSERT INTO patients VALUES (4, 'gana', 'free detection', '2024-05-23', '2024-07-01');
INSERT INTO patients VALUES (5, 'aya', 'no insurance', '2024-08-05', '2024-10-05');
INSERT INTO patients VALUES (6, 'rokia', 'no insurance', '2024-06-25', '2024-12-01');

-- Update date_admitted for patient with ssn = 1
UPDATE patients SET date_admitted = '2024-03-23' WHERE ssn = 1;

-- Delete patient named 'seif'
DELETE FROM patients WHERE name = 'seif';

-- Create doctors table
CREATE TABLE doctors (
    dssn INT PRIMARY KEY,
    name NVARCHAR(100),
    specialization NVARCHAR(50)
);

-- Insert data into doctors table
INSERT INTO doctors VALUES (1, 'shahd', 'rhinology');
INSERT INTO doctors VALUES (2, 'haneen', 'oral health');
INSERT INTO doctors VALUES (3, 'rahma', 'orthopedics');
INSERT INTO doctors VALUES (4, 'mariam', 'ophthalmology');
INSERT INTO doctors VALUES (5, 'mohamed', 'cardiology');
INSERT INTO doctors VALUES (6, 'hassan', 'gastroenterology');

-- Delete doctor named 'mariam'
DELETE FROM doctors WHERE name = 'mariam';

-- Update doctor name to 'rahma' where dssn = 3
UPDATE doctors SET name = 'rahma' WHERE dssn = 3;

-- Create test table
CREATE TABLE test (
    id INT PRIMARY KEY,
    name NVARCHAR(100),
    date DATE,
    time TIME,
    result NVARCHAR(50)
);

-- Insert data into test table
INSERT INTO test VALUES (1, 'blood test', '2024-05-04', '02:55:00', 'low');
INSERT INTO test VALUES (2, 'Sugar check', '2024-07-07', '12:55:00', 'natural');
INSERT INTO test VALUES (3, 'Vitamin D analysis', '2024-03-03', '04:00:00', 'natural');
INSERT INTO test VALUES (4, 'Urine examination', '2024-01-01', '03:15:00', 'natural');
INSERT INTO test VALUES (5, 'Pregnancy', '2024-05-04', '01:30:00', 'positive');
INSERT INTO test VALUES (6, 'Imaging tests', '2024-07-07', '11:30:00', 'hand is broken');

-- Delete test where name is 'Sugar check'
DELETE FROM test WHERE name = 'Sugar check';

-- Update test name to 'blood test' where id = 1
UPDATE test SET name = 'blood test' WHERE id = 1;

-- Display all records from the test table
SELECT * FROM test;
